#!/bin/bash
uvicorn backend.server:app --reload
